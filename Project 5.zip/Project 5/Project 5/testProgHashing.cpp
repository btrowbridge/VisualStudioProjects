

#include <iostream>
#include "hashT.h"

using namespace std;


void problem2() {
	cout << "/n/n/n============================|Problem 2|=======================================/n/n/n" << endl;
}